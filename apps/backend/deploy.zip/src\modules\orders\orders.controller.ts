import {
  Controller,
  Get,
  Post,
  Patch,
  Body,
  Param,
  Query,
  UseGuards,
  Request,
  HttpException,
  InternalServerErrorException,
  Logger,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { OrdersService } from './orders.service';
import { OrderLifecycleService } from './order-lifecycle.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderStatusDto } from './dto/update-order-status.dto';
import { CancelOrderDto } from './dto/cancel-order.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { OrderStatus, DriverStatus, DeliveryJobStatus } from '@prisma/client';
import { PrismaService } from '../database/prisma.service';
import { GeolocationService } from '../geolocation/geolocation.service';

@ApiTags('Orders (Phase 10)')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('orders')
export class OrdersController {
  private readonly logger = new Logger(OrdersController.name);

  constructor(
    private readonly ordersService: OrdersService,
    private readonly lifecycleService: OrderLifecycleService,
    private readonly prisma: PrismaService,
    private readonly geoService: GeolocationService,
  ) {}

  @Get()
  @ApiOperation({ summary: 'Get list of orders (filterable by restaurantId & status)' })
  @ApiQuery({ name: 'restaurantId', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  async findAll(
    @Request() req: any,
    @Query('restaurantId') restaurantId?: string,
    @Query('status') status?: string,
    @Query('page') page = 1,
    @Query('limit') limit = 20,
  ) {
    const isAdmin = req.user?.role === 'SUPER_ADMIN' || req.user?.role === 'ADMIN';

    // ADMIN ROUTE: Always use getAllOrders for admins.
    // Admins can optionally filter by restaurantId via query param, but their JWT restaurantId
    // must never be used to scope them — admins see ALL platform orders.
    if (isAdmin) {
      if (restaurantId) {
        // Admin explicitly filtering by a specific restaurant
        return this.ordersService.getRestaurantOrders(restaurantId, status as any, +page, +limit);
      }
      return this.ordersService.getAllOrders(status as any, +page, +limit);
    }

    // NON-ADMIN ROUTE: scope to the restaurant the user owns/manages
    const targetRestId = restaurantId || req.user?.restaurantId;

    if (targetRestId) {
      const userId = req.user?.id || req.user?.sub;
      const ownsRestaurant = await this.prisma.restaurant.findFirst({
        where: { id: targetRestId, ownerId: userId },
        select: { id: true },
      });
      const isStaff = await this.prisma.restaurantStaff.findFirst({
        where: { restaurantId: targetRestId, userId },
        select: { id: true },
      });
      if (!ownsRestaurant && !isStaff) {
        throw new ForbiddenException(
          'Access denied. You do not own or manage this restaurant orders.',
        );
      }
      return this.ordersService.getRestaurantOrders(targetRestId, status as any, +page, +limit);
    }

    return this.ordersService.getCustomerOrders(req.user.id || req.user.sub, +page, +limit);
  }

  @Post()
  @ApiOperation({ summary: 'Create a new order (Checkout)' })
  async create(@Body() createOrderDto: CreateOrderDto, @Request() req: any) {
    const customerId = req.user.id || req.user.sub;
    return this.ordersService.createOrder(customerId, createOrderDto);
  }

  @Get('active')
  @ApiOperation({ summary: 'Get active order tracking for current customer' })
  async getActiveOrder(@Request() req: any) {
    const userId = req.user.id || req.user.sub;
    return this.ordersService.getActiveCustomerOrder(userId);
  }

  @Get('history')
  @ApiOperation({ summary: 'Get customer order history with status filter' })
  async getOrderHistory(@Request() req: any, @Query('status') status?: string, @Query('page') page = 1, @Query('limit') limit = 20) {
    const userId = req.user.id || req.user.sub;
    return this.ordersService.getCustomerOrderHistory(userId, status, +page, +limit);
  }

  @Get('my')
  @ApiOperation({ summary: 'Get customer order history' })
  async getMyOrdersAlias(@Request() req: any, @Query('status') status?: string, @Query('page') page = 1, @Query('limit') limit = 20) {
    const userId = req.user.id || req.user.sub;
    return this.ordersService.getCustomerOrderHistory(userId, status, +page, +limit);
  }

  @Get('my-orders')
  @ApiOperation({ summary: 'Get customer order history' })
  async getMyOrders(
    @Request() req: any,
    @Query('page') page = 1,
    @Query('limit') limit = 10,
    @Query('status') status?: string,
  ) {
    const userId = req.user.id || req.user.sub;
    if (status) {
      return this.ordersService.getCustomerOrderHistory(userId, status, +page, +limit);
    }
    return this.ordersService.getCustomerOrders(userId, +page, +limit);
  }

  @Post(':id/confirm-delivery')
  @ApiOperation({ summary: 'Customer or authorized actor confirms order delivery via OTP' })
  async confirmDelivery(@Param('id') id: string, @Body('otp') otp: string, @Request() req: any) {
    if (!otp) throw new BadRequestException('Delivery confirmation OTP is required.');
    const actor = {
      userId: req.user?.id || req.user?.sub,
      role: req.user?.role,
      driverId: req.user?.driverId,
    };
    return this.lifecycleService.completeDeliveryWithOtp(id, otp, actor);
  }

  @Post(':id/verify-delivery')
  @ApiOperation({ summary: 'Verify delivery OTP (authoritative alias)' })
  async verifyDelivery(@Param('id') id: string, @Body('otp') otp: string, @Request() req: any) {
    return this.confirmDelivery(id, otp, req);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get order by ID' })
  async findOne(@Param('id') id: string, @Request() req: any) {
    const userId = req.user?.id || req.user?.sub;
    const role = req.user?.role;
    return this.ordersService.getOrderWithTimelineSecured(id, userId, role);
  }

  @Get(':id/tracking')
  @ApiOperation({ summary: 'Get live tracking coordinates for order' })
  async tracking(@Param('id') id: string, @Request() req: any) {
    const userId = req.user?.id || req.user?.sub;
    const role = req.user?.role;
    return this.ordersService.getOrderTrackingSecured(id, userId, role);
  }

  @Get(':id/invoice')
  @ApiOperation({ summary: 'Get or generate financial invoice based on pricing snapshot' })
  async getInvoice(@Param('id') id: string, @Request() req: any) {
    const userId = req.user?.id || req.user?.sub;
    const role = req.user?.role;
    return this.ordersService.getOrderInvoice(id, userId, role);
  }

  @Get(':id/eligible-riders')
  @ApiOperation({
    summary: 'Get eligible FoodHub delivery partners for explicit restaurant rider selection',
  })
  async getEligibleRiders(@Param('id') id: string, @Request() req: any) {
    const order = await this.prisma.order.findUnique({
      where: { id },
      include: { restaurant: true },
    });

    if (!order) {
      throw new BadRequestException(`Order with ID "${id}" not found.`);
    }

    const isOwner = order.restaurant?.ownerId === (req.user?.id || req.user?.sub);
    const isStaff = req.user?.restaurantId && req.user.restaurantId === order.restaurantId;
    const isAdmin = req.user?.role === 'ADMIN' || req.user?.role === 'SUPER_ADMIN';

    if (!isOwner && !isStaff && !isAdmin) {
      throw new ForbiddenException(
        'Access denied. You do not own or manage this restaurant order.',
      );
    }

    const restLat = Number(order.restaurant.latitude || 0);
      const restLng = Number(order.restaurant.longitude || 74.5221);

      const latDiff = 5.0 / 111.0;
      const lngDiff = 5.0 / (111.0 * Math.cos(restLat * Math.PI / 180));
      
      const drivers = await this.prisma.driver.findMany({
        where: {
          isApproved: true,
          status: 'ONLINE',
          user: { isActive: true },
          currentLat: { gte: restLat - latDiff, lte: restLat + latDiff },
          currentLng: { gte: restLng - lngDiff, lte: restLng + lngDiff },
        },
        include: {
          user: { include: { profile: true } },
          vehicles: true,
          deliveryJobs: {
            where: {
              status: {
                in: ['ASSIGNED', 'ARRIVED', 'PICKED_UP', 'DELIVERED']
              }
            },
            take: 100,
            orderBy: { createdAt: 'desc' }
          },
          reviews: { take: 10, orderBy: { createdAt: 'desc' } },
        },
        take: 200,
      });

    
    const now = new Date();

    const getHaversine = (lat1: number, lon1: number, lat2: number, lon2: number) => {
      const R = 6371;
      const dLat = ((lat2 - lat1) * Math.PI) / 180;
      const dLon = ((lon2 - lon1) * Math.PI) / 180;
      const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos((lat1 * Math.PI) / 180) *
          Math.cos((lat2 * Math.PI) / 180) *
          Math.sin(dLon / 2) *
          Math.sin(dLon / 2);
      return Math.round(R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))) * 10) / 10;
    };

    
    const filteredDrivers = drivers.filter(d => {
      if (!d.user?.isActive || !d.isApproved || d.status === DriverStatus.OFFLINE) return false;
      if (!d.currentLat || !d.currentLng) return false;
      
      const distanceKm = getHaversine(restLat, restLng, d.currentLat, d.currentLng);
      return distanceKm <= 5.0;
    });

    return filteredDrivers.map((d) => {
      const activeJobs = d.deliveryJobs.filter((j) =>
        [
          DeliveryJobStatus.ASSIGNED as string,
          DeliveryJobStatus.ARRIVED as string,
          DeliveryJobStatus.PICKED_UP as string,
        ].includes(j.status as string),
      );
      const completedJobs = d.deliveryJobs.filter((j) => j.status === DeliveryJobStatus.DELIVERED);

      const firstName = d.user?.profile?.firstName || 'Partner';
      const lastName = d.user?.profile?.lastName || '';
      const phone = d.user?.phone || '';
      const vehicle = d.vehicles[0];

      let distanceKm: number | null = null;
      let distanceText = 'Location unavailable';

      if (d.currentLat && d.currentLng) {
        if (d.lastSeenAt && now.getTime() - new Date(d.lastSeenAt).getTime() > 15 * 60 * 1000) {
          distanceText = 'Location outdated';
        } else {
          distanceKm = getHaversine(restLat, restLng, d.currentLat, d.currentLng);
          distanceText = `${distanceKm} km away`;
        }
      }

      // Real calculated rating
      const avgRating = Number(d.avgRating) > 0 ? Number(d.avgRating) : 5.0;

      // Real status calculation
      let status = 'ONLINE_AVAILABLE';
      let isAvailable = true;
      let unavailabilityReason: string | null = null;

      if (!d.user?.isActive) {
        status = 'SUSPENDED';
        isAvailable = false;
        unavailabilityReason = 'User account suspended';
      } else if (!d.isApproved) {
        status = 'PENDING_APPROVAL';
        isAvailable = false;
        unavailabilityReason = 'Pending admin approval';
      } else if (d.status === DriverStatus.OFFLINE) {
        status = 'OFFLINE';
        isAvailable = false;
        unavailabilityReason = 'Rider is currently offline';
      } else if (activeJobs.length >= parseInt(process.env.RIDER_MAX_ACTIVE_ORDERS || '10', 10)) {
        status = 'BUSY';
        isAvailable = false;
        unavailabilityReason = `Rider is at max capacity (${activeJobs.length} active orders)`;
      }

      return {
        id: d.id,
        driverId: d.id,
        userId: d.userId,
        name: `${firstName} ${lastName}`.trim(),
        firstName,
        lastName,
        phone,
        avatar:
          d.user?.profile?.avatarUrl ||
          `https://api.dicebear.com/7.x/avataaars/svg?seed=${firstName}`,
        rating: avgRating,
        completedCount: completedJobs.length,
        status,
        isAvailable,
        unavailabilityReason,
        isApproved: d.isApproved,
        vehicleType: vehicle?.vehicleType || 'Motorcycle',
        vehicleNumber: vehicle?.vehicleNumber || 'N/A',
        distanceKm,
        distanceText,
      };
    });
  }

  @Post(':id/assign-rider')
  @ApiOperation({ summary: 'Restaurant explicitly assigns selected FoodHub delivery partner' })
  async assignRider(
    @Param('id') id: string,
    @Body('driverId') driverId: string,
    @Request() req: any,
  ) {
    try {
      if (!driverId) throw new BadRequestException('driverId parameter is required.');
      const actor = {
        userId: req.user?.id || req.user?.sub,
        role: req.user?.role,
        restaurantId: req.user?.restaurantId,
      };
      return await this.lifecycleService.assignRiderToOrder(id, driverId, actor);
    } catch (err: any) {
      if (err instanceof HttpException) throw err;
      this.logger.error(`ASSIGN RIDER FAILED for order ${id}: ${err?.message}`, err?.stack);
      throw new InternalServerErrorException({
        message: err?.message || 'Failed to assign rider to order.',
        details: err?.stack || String(err),
      });
    }
  }

  @Post(':id/accept')
  @ApiOperation({ summary: 'Restaurant accepts pending order' })
  async acceptOrder(@Param('id') id: string, @Request() req: any) {
    try {
      const actor = {
        userId: req.user?.id || req.user?.sub,
        role: req.user?.role,
        restaurantId: req.user?.restaurantId,
      };
      return await this.lifecycleService.transition(id, OrderStatus.ACCEPTED, actor);
    } catch (err: any) {
      if (err instanceof HttpException) throw err;
      this.logger.error(
        `ACCEPT ORDER TRANSITION FAILED for order ${id}: ${err?.message}`,
        err?.stack,
      );
      throw new InternalServerErrorException({
        message: err?.message || 'Restaurant order service temporarily failed.',
        details: err?.stack || String(err),
      });
    }
  }

  @Post(':id/reject')
  @ApiOperation({ summary: 'Restaurant rejects pending order' })
  async rejectOrder(@Param('id') id: string, @Body('reason') reason: string, @Request() req: any) {
    try {
      const actor = {
        userId: req.user?.id || req.user?.sub,
        role: req.user?.role,
        restaurantId: req.user?.restaurantId,
      };
      return await this.lifecycleService.transition(id, OrderStatus.REJECTED, actor, { reason });
    } catch (err: any) {
      if (err instanceof HttpException) throw err;
      this.logger.error(
        `REJECT ORDER TRANSITION FAILED for order ${id}: ${err?.message}`,
        err?.stack,
      );
      throw new InternalServerErrorException({
        message: err?.message || 'Restaurant order service temporarily failed.',
        details: err?.stack || String(err),
      });
    }
  }

  @Post(':id/prepare')
  @ApiOperation({ summary: 'Restaurant starts preparing accepted order' })
  async startPreparingOrder(@Param('id') id: string, @Request() req: any) {
    try {
      const actor = {
        userId: req.user?.id || req.user?.sub,
        role: req.user?.role,
        restaurantId: req.user?.restaurantId,
      };
      return await this.lifecycleService.transition(id, OrderStatus.PREPARING, actor);
    } catch (err: any) {
      if (err instanceof HttpException) throw err;
      this.logger.error(
        `PREPARE ORDER TRANSITION FAILED for order ${id}: ${err?.message}`,
        err?.stack,
      );
      throw new InternalServerErrorException({
        message: err?.message || 'Restaurant order service temporarily failed.',
        details: err?.stack || String(err),
      });
    }
  }

  @Post(':id/ready')
  @ApiOperation({
    summary:
      'Restaurant marks order ready — triggers driver dispatch (PREPARING → DRIVER_ASSIGNED)',
  })
  async markOrderReady(@Param('id') id: string, @Request() req: any) {
    try {
      const actor = {
        userId: req.user?.id || req.user?.sub,
        role: req.user?.role,
        restaurantId: req.user?.restaurantId,
      };
      return await this.lifecycleService.transition(id, OrderStatus.DRIVER_ASSIGNED, actor);
    } catch (err: any) {
      if (err instanceof HttpException) throw err;
      this.logger.error(
        `READY ORDER TRANSITION FAILED for order ${id}: ${err?.message}`,
        err?.stack,
      );
      throw new InternalServerErrorException({
        message: err?.message || 'Restaurant order service temporarily failed.',
        details: err?.stack || String(err),
      });
    }
  }

  @Patch(':id/status')
  @ApiOperation({ summary: 'Update order status via state machine' })
  async updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateOrderStatusDto,
    @Request() req: any,
  ) {
    try {
      const actor = {
        userId: req.user?.id || req.user?.sub,
        role: req.user?.role,
        restaurantId: req.user?.restaurantId,
        driverId: req.user?.driverId,
      };
      return await this.lifecycleService.transition(id, dto.status as OrderStatus, actor);
    } catch (err: any) {
      if (err instanceof HttpException) throw err;
      this.logger.error(`UPDATE ORDER STATUS FAILED for order ${id}: ${err?.message}`, err?.stack);
      throw new InternalServerErrorException({
        message: err?.message || 'Restaurant order service temporarily failed.',
        details: err?.stack || String(err),
      });
    }
  }

  @Post(':id/cancel')
  @ApiOperation({ summary: 'Cancel order (within cancellation policy)' })
  async cancel(@Param('id') id: string, @Body() cancelDto: CancelOrderDto, @Request() req: any) {
    const userId = req.user?.id;
    return this.ordersService.cancelOrder(id, cancelDto, userId);
  }

  @Get(':id/pickup-otp')
  @ApiOperation({
    summary:
      'Authorized restaurant staff retrieves 4-digit pickup code & signed QR token for order handover',
  })
  async getPickupOtp(@Param('id') id: string, @Request() req: any) {
    const actor = {
      userId: req.user?.id || req.user?.sub,
      role: req.user?.role,
      restaurantId: req.user?.restaurantId,
    };
    return this.lifecycleService.getRestaurantPickupOtp(id, actor);
  }

  @Post(':id/reviews')
  @ApiOperation({ summary: 'Customer submits review and rating for delivered order' })
  async submitReview(
    @Param('id') id: string,
    @Body('rating') rating: number,

    @Request() req: any,
  ) {
    const userId = req.user?.id || req.user?.sub;
    return this.ordersService.submitOrderReview(id, rating, userId);
  }

  @Post(':id/review')
  @ApiOperation({ summary: 'Customer submits review (alias)' })
  async submitReviewAlias(
    @Param('id') id: string,
    @Body('rating') rating: number,

    @Request() req: any,
  ) {
    const userId = req.user?.id || req.user?.sub;
    return this.ordersService.submitOrderReview(id, rating, userId);
  }

  @Post(':id/repeat')
  @ApiOperation({ summary: 'Customer fetches items to repeat previous order' })
  async repeatOrder(@Param('id') id: string, @Request() req: any) {
    const userId = req.user?.id || req.user?.sub;
    return this.ordersService.repeatOrder(id, userId);
  }
}

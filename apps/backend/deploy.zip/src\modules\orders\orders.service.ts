import { OnApplicationBootstrap } from '@nestjs/common';
import { GeolocationService } from '../geolocation/geolocation.service';
import { RedisService } from '../redis/redis.service';
import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  UnauthorizedException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';
import { OrdersRepository } from './orders.repository';
import { OrdersValidationService } from './orders.validation.service';
import { OrderLifecycleService } from './order-lifecycle.service';
import { OrdersGateway } from './orders.gateway';
import { CreateOrderDto } from './dto/create-order.dto';
import { serializePrisma } from '../../common/utils/serializer.util';
import { UpdateOrderStatusDto } from './dto/update-order-status.dto';
import { CancelOrderDto } from './dto/cancel-order.dto';
import { ORDER_EVENTS } from './orders.events';
import { OrderStatus, Prisma } from '@prisma/client';

import { OrderQuoteService } from '../tax/order-quote.service';
import { CouponsService } from '../coupons/coupons.service';
import { hashOtp } from './order-lifecycle.service';
import * as crypto from 'crypto';
import { WebPushService } from '../notifications/web-push.service';

/** Generates a unique order number like FH-948210 */
function generateOrderNumber(): string {
  const num = crypto.randomInt(100000, 1000000);
  return `FH-${num}`;
}

@Injectable()
export class OrdersService implements OnApplicationBootstrap {
  private readonly logger = new Logger(OrdersService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly repo: OrdersRepository,
    private readonly validation: OrdersValidationService,
    private readonly lifecycle: OrderLifecycleService,
    private readonly gateway: OrdersGateway,
    private readonly quoteService: OrderQuoteService,
    private readonly geolocationService: GeolocationService,
    private readonly webPushService: WebPushService,
    private readonly redisService: RedisService,
    private readonly couponsService: CouponsService,
  ) {}

  onApplicationBootstrap() {
    // Run order timeout check every 1 minute
    setInterval(async () => {
      try {
        const lockAcquired = await this.redisService.getClient().set('lock:order_timeouts', '1', 'EX', 55, 'NX');
        if (lockAcquired) {
          await this.handleOrderTimeouts();
        }
      } catch (err) {
        this.logger.error('Error in order timeout scheduler', err);
      }
    }, 60 * 1000);
  }

  private async handleOrderTimeouts() {
    const now = Date.now();
    const tenMinutesAgo = new Date(now - 10 * 60 * 1000);
    const fiveHoursAgo = new Date(now - 5 * 60 * 60 * 1000);
    
    // -----------------------------------------------------
    // RULE A: 10-MINUTE RESTAURANT ACCEPTANCE TIMEOUT
    // -----------------------------------------------------
    const expiredPendingOrders = await this.prisma.order.findMany({
      where: {
        status: OrderStatus.PENDING,
        createdAt: { lt: tenMinutesAgo }
      },
      select: { id: true, createdAt: true }
    });

    for (const order of expiredPendingOrders) {
      try {
        await this.lifecycle.updateOrderStatus(
          order.id,
          OrderStatus.CANCELLED,
          'SYSTEM', // Special actor
          { cancellationReason: 'Restaurant acceptance timeout (10 minutes)' }
        );
        
        await this.prisma.orderCancellation.create({
          data: {
            orderId: order.id,
            reason: 'Restaurant acceptance timeout (10 minutes)',
            cancelledBy: 'SYSTEM'
          }
        });
        
        this.logger.log(`Order ${order.id} was auto-cancelled due to 10-minute acceptance timeout.`);
      } catch (err: any) {
        if (err.name !== 'ConflictException') {
          this.logger.error(`Failed to auto-cancel expired order ${order.id} (10-min rule): ${err.message}`);
        }
      }
    }

    // -----------------------------------------------------
    // RULE B: 5-HOUR MAXIMUM ORDER LIFECYCLE TIMEOUT
    // -----------------------------------------------------
    const overdueOrders = await this.prisma.order.findMany({
      where: {
        status: {
          notIn: [
            OrderStatus.DELIVERED,
            OrderStatus.CANCELLED,
            OrderStatus.REJECTED,
            OrderStatus.FAILED,
            OrderStatus.REFUNDED
          ]
        },
        createdAt: { lt: fiveHoursAgo }
      },
      select: { id: true, createdAt: true }
    });

    for (const order of overdueOrders) {
      try {
        // Use the lifecycle service to safely cancel, handle DeliveryJob rollback, timelines, and events
        await this.lifecycle.updateOrderStatus(
          order.id,
          OrderStatus.CANCELLED,
          'SYSTEM', // Special actor
          { cancellationReason: 'Maximum order lifecycle timeout exceeded (5 hours).' }
        );

        // Ensure cancellation record is explicitly tracked
        await this.prisma.orderCancellation.create({
          data: {
            orderId: order.id,
            reason: 'Maximum order lifecycle timeout exceeded (5 hours)',
            cancelledBy: 'SYSTEM'
          }
        });

        this.logger.log(`Order ${order.id} was auto-cancelled due to 5-hour maximum lifecycle timeout.`);
      } catch (err: any) {
        // Ignore ConflictException if the race condition was already won by a valid terminal transition
        if (err.name !== 'ConflictException') {
          this.logger.error(`Failed to auto-cancel overdue order ${order.id} (5-hour rule): ${err.message}`);
        }
      }
    }
  }

  async createOrder(customerIdOrUserId: string, dto: CreateOrderDto) {
    const isUuid =
      /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(
        customerIdOrUserId,
      );

    // Look up customer by userId OR customer id in PostgreSQL
    let existingCustomer = isUuid
      ? await this.prisma.customer.findFirst({
          where: {
            OR: [{ userId: customerIdOrUserId }, { id: customerIdOrUserId }],
          },
        })
      : null;

    if (!existingCustomer && isUuid) {
      // Auto-create Customer record for authenticated User if missing
      const existingUser = await this.prisma.user.findUnique({ where: { id: customerIdOrUserId } });
      if (existingUser) {
        existingCustomer = await this.prisma.customer.create({
          data: { userId: existingUser.id },
        });
      }
    }

    let targetCustomerId: string;

    if (existingCustomer) {
      targetCustomerId = existingCustomer.id;
    } else {
      throw new UnauthorizedException('Authenticated customer profile required to place an order.');
    }

    // 1. Validate restaurant open & status
    await this.validation.validateRestaurantOpen(dto.restaurantId);

    // 1.1 Validate delivery radius (server-side security check)
    const calculatedDistanceKm = await this.validation.validateDeliveryRadius(
      dto.restaurantId,
      dto.deliveryAddress,
    );

    // 2. Validate items & inventory
    await this.validation.validateItemsAvailable(dto.items, dto.restaurantId);

    // 3. Calculate subtotal with authoritative server-side price resolution
    let subtotal = 0;
    const itemsWithPrices: Array<{
      foodItemId: string;
      variantId: string | null;
      variantName: string | null;
      quantity: number;
      unitPrice: number;
      totalPrice: number;
      addonsJson: Prisma.InputJsonValue | typeof Prisma.JsonNull;
      itemSnapshot: Prisma.InputJsonValue | typeof Prisma.JsonNull;
    }> = [];

    for (const item of dto.items) {
      const food = await this.prisma.foodItem.findUnique({
        where: { id: item.foodItemId },
        include: { variants: true },
      });
      if (!food) {
        throw new BadRequestException(`Food item ${item.foodItemId} not found.`);
      }

      if (food.restaurantId !== dto.restaurantId) {
        throw new BadRequestException(
          `Food item "${food.name}" does not belong to restaurant ${dto.restaurantId}.`,
        );
      }

      let resolvedUnitPrice = Number(food.price);
      let selectedVariantName: string | null = null;
      let selectedVariantId: string | null = null;

      if (item.variantId) {
        const variant = (food.variants || []).find((v) => v.id === item.variantId);
        if (!variant) {
          throw new BadRequestException(`Variant ${item.variantId} not found for "${food.name}".`);
        }
        if (!variant.isAvailable) {
          throw new BadRequestException(
            `Variant "${variant.variantName}" of "${food.name}" is currently unavailable.`,
          );
        }
        resolvedUnitPrice = Number(variant.price);
        selectedVariantId = variant.id;
        selectedVariantName = variant.variantName;
      } else if (item.variantName) {
        const variant = (food.variants || []).find(
          (v) => v.variantName.toLowerCase() === item.variantName!.toLowerCase(),
        );
        if (variant) {
          if (!variant.isAvailable) {
            throw new BadRequestException(
              `Variant "${variant.variantName}" of "${food.name}" is currently unavailable.`,
            );
          }
          resolvedUnitPrice = Number(variant.price);
          selectedVariantId = variant.id;
          selectedVariantName = variant.variantName;
        }
      }

      const addonTotal = item.addonsJson
        ? (item.addonsJson as Array<{ price: number }>).reduce((sum, a) => sum + (a.price || 0), 0)
        : 0;
      const unitPrice = resolvedUnitPrice + addonTotal;
      const totalPrice = unitPrice * item.quantity;
      subtotal += totalPrice;

      const itemSnapshot = {
        foodItemId: food.id,
        foodName: food.name,
        variantId: selectedVariantId,
        variantName: selectedVariantName,
        basePrice: resolvedUnitPrice,
        addonTotal,
        unitPrice,
        quantity: item.quantity,
        totalPrice,
      };

      itemsWithPrices.push({
        foodItemId: item.foodItemId,
        variantId: selectedVariantId,
        variantName: selectedVariantName,
        quantity: item.quantity,
        unitPrice,
        totalPrice,
        addonsJson: item.addonsJson ? (item.addonsJson as Prisma.InputJsonValue) : Prisma.JsonNull,
        itemSnapshot: itemSnapshot as unknown as Prisma.InputJsonValue,
      });
    }

    // 4. Validate minimum order
    await this.validation.validateMinimumOrder(dto.restaurantId, subtotal);

    // 5. Apply Coupon Discount
    let discountAmount = 0;
    let validCouponId: string | undefined = undefined;

    if (dto.couponCode) {
      const couponVal = await this.couponsService.validateCoupon(
        dto.couponCode,
        targetCustomerId,
        subtotal,
        dto.restaurantId
      );
      if (couponVal.valid) {
        discountAmount = couponVal.discountAmount;
        validCouponId = couponVal.couponId;
      } else {
        throw new BadRequestException(couponVal.message);
      }
    }

    // Construct authoritative immutable deliveryAddress snapshot & calculate Mappls road distance
    const rawAddress: any = dto.deliveryAddress || {};

    let formattedAddressText = '';
    if (typeof rawAddress === 'string') {
      formattedAddressText = rawAddress;
    } else if (rawAddress.formattedAddress) {
      formattedAddressText = rawAddress.formattedAddress;
    } else if (rawAddress.addressLine1) {
      formattedAddressText = [
        rawAddress.addressLine1,
        rawAddress.addressLine2,
        rawAddress.landmark ? `Landmark: ${rawAddress.landmark}` : null,
        rawAddress.city,
        rawAddress.state
          ? `${rawAddress.state}${rawAddress.postalCode ? ` - ${rawAddress.postalCode}` : ''}`
          : null,
      ]
        .filter(Boolean)
        .join(', ');
    } else if (rawAddress.placeName) {
      formattedAddressText = rawAddress.placeName;
    } else {
      formattedAddressText = 'Location address not provided';
    }

    const placeNameText =
      typeof rawAddress === 'object' && rawAddress.placeName
        ? rawAddress.placeName
        : formattedAddressText.split(',')[0] || 'Delivery Address';

    const latitudeNum =
      typeof rawAddress === 'object' && typeof rawAddress.latitude === 'number'
        ? rawAddress.latitude
        : (dto as any).latitude || (dto as any).lat;

    const longitudeNum =
      typeof rawAddress === 'object' && typeof rawAddress.longitude === 'number'
        ? rawAddress.longitude
        : (dto as any).longitude || (dto as any).lng;

    const locationSourceText =
      typeof rawAddress === 'object' && rawAddress.locationSource
        ? rawAddress.locationSource
        : (dto as any).locationSource || 'CURRENT_GPS';

    // Fetch restaurant coordinates for authoritative server-side distance calculation
    const restaurant = await this.prisma.restaurant.findUnique({
      where: { id: dto.restaurantId },
    });
    const restLat = restaurant ? Number(restaurant.latitude) : 0;
    const restLng = restaurant ? Number(restaurant.longitude) : 74.5221;

    this.logger.log({
      msg: 'Order creation input',
      restaurantId: dto.restaurantId,
      itemCount: dto.items.length,
      locationSource: locationSourceText,
      latitude: latitudeNum,
      longitude: longitudeNum,
    });

    // Authoritative Quote Calculation (Customer Packaging Fee = ₹0)
    const quote = await this.quoteService.calculateQuote({
      foodSubtotal: subtotal,
      distanceKm: calculatedDistanceKm,
      restaurantId: dto.restaurantId,
      locationSource: locationSourceText as any,
      couponCode: dto.couponCode,
      customerId: targetCustomerId,
      packagingFee: 0,
      tipAmount: (dto as any).tipAmount || 0,
    });

    this.logger.log({
      msg: 'Order quote calculated',
      calculatedDistanceKm: quote.distanceKm,
      calculatedDeliveryFee: quote.customerDeliveryFee,
      calculatedCustomerTaxes: quote.totalCustomerTaxes,
      calculatedCustomerTotal: quote.customerTotal,
    });

    if (quote.customerDeliveryFee === null || quote.customerTotal === null) {
      throw new BadRequestException('Delivery route is unavailable for the selected location.');
    }

    const deliveryFee = quote.customerDeliveryFee;
    const taxAmount = quote.totalCustomerTaxes;
    const totalAmount = quote.customerTotal;

    const pricingSnapshot = {
      commissionRate: quote.commissionRate,
      commissionStatus: quote.commissionStatus,
      commissionAmount: quote.restaurantCommission,
      commissionGstAmount: quote.restaurantCommissionGst,
      restaurantCommissionPercent: quote.restaurantCommissionPercent,
      restaurantCommissionAmount: quote.restaurantCommission,
      restaurantCommissionGst: quote.restaurantCommissionGst,
      restaurantGross: subtotal,
      restaurantNet: quote.restaurantSettlement,
      platformRevenue: quote.platformOperatingRevenue,
      platformFee: quote.platformFee,
      smallOrderThreshold: 0,
      smallOrderSurcharge: 0,
      customerDeliveryFee: quote.customerDeliveryFee,
      deliveryDistanceKm: quote.deliveryDistanceKm,
      deliveryFeeBaseKm: quote.deliveryFeeBaseKm,
      deliveryFeeBaseAmount: quote.deliveryFeeBaseAmount,
      deliveryFeePerExtraKm: quote.deliveryFeePerExtraKm,
      riderBasePayout: quote.riderBasePay,
      riderPerKmRate: 6,
      riderPayout: quote.totalRiderPayout,
      paymentGatewayCost: quote.paymentGatewayCost,
      restaurantSettlement: quote.restaurantSettlement,
      packagingFee: 0,
      discountAmount,
      statutoryGstLiability: 0,
      platformContributionMargin: quote.platformContributionMargin,
    };

    const deliveryAddressSnapshot = {
      placeName: placeNameText,
      formattedAddress: formattedAddressText,
      addressLine1:
        typeof rawAddress === 'object'
          ? rawAddress.addressLine1 || placeNameText
          : formattedAddressText,
      addressLine2: typeof rawAddress === 'object' ? rawAddress.addressLine2 || '' : '',
      landmark: typeof rawAddress === 'object' ? rawAddress.landmark || '' : '',
      city: typeof rawAddress === 'object' ? rawAddress.city || '' : '',
      state:
        typeof rawAddress === 'object' ? rawAddress.state || 'Jammu & Kashmir' : 'Jammu & Kashmir',
      postalCode: typeof rawAddress === 'object' ? rawAddress.postalCode || '193502' : '193502',
      latitude: latitudeNum,
      longitude: longitudeNum,
      locationSource: locationSourceText,
      verificationStatus: 'VERIFIED',
      distanceKm: quote.distanceKm,
      deliveryFee: quote.customerDeliveryFee,
    };

    // 7. Create order in transaction
    const order = await this.prisma.$transaction(async (tx) => {
      const newOrder = await tx.order.create({
        data: {
          orderNumber: generateOrderNumber(),
          customerId: targetCustomerId,
          restaurantId: dto.restaurantId,
          status: OrderStatus.PENDING,
          subtotal,
          packagingFee: 0,
          deliveryFee,
          taxAmount,
          discountAmount,
          totalAmount,
          paymentMethod: dto.paymentMethod,
          deliveryAddress: deliveryAddressSnapshot as Prisma.InputJsonValue,
          taxSnapshot: quote.taxItems as unknown as Prisma.InputJsonValue,
          pricingSnapshot: pricingSnapshot as unknown as Prisma.InputJsonValue,
          specialInstruction: dto.specialInstruction,
        },
      });

      // Record coupon usage safely in transaction
      if (validCouponId) {
        await tx.couponUsage.create({
          data: {
            couponId: validCouponId,
            customerId: targetCustomerId,
            orderId: newOrder.id,
          },
        });
      }

      // Create order items via createMany with complete variant & snapshot fields
      await tx.orderItem.createMany({
        data: itemsWithPrices.map((item) => ({
          orderId: newOrder.id,
          foodItemId: item.foodItemId,
          variantId: item.variantId,
          variantName: item.variantName,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          totalPrice: item.totalPrice,
          addonsJson: item.addonsJson,
          itemSnapshot: item.itemSnapshot,
        })),
      });

      // Append initial timeline entry
      await tx.orderTimeline.create({
        data: {
          orderId: newOrder.id,
          status: OrderStatus.PENDING,
          message: 'Order placed successfully',
        },
      });

      return newOrder;
    });

    // 9. Emit real-time event to restaurant — ONLY for COD orders.
    // Online payment orders (UPI, CARD, NETBANKING, WALLET, etc.) must NOT appear in
    // the restaurant queue until server-side payment verification succeeds.
    // The PaymentsService emits ORDER_CREATED after verifyPayment() or the Razorpay webhook fires.
    if (dto.paymentMethod === 'COD') {
      this.webPushService.sendPushNotification(dto.restaurantId, {
        title: 'New Order Received',
        body: `Order #${order.orderNumber} for ₹${order.totalAmount} is waiting for acceptance.`,
        url: '/orders',
      });
      this.gateway.emitToRestaurant(dto.restaurantId, ORDER_EVENTS.ORDER_CREATED, {
        orderId: order.id,
        orderNumber: order.orderNumber,
        totalAmount: order.totalAmount,
        deliveryAddress: deliveryAddressSnapshot,
        deliveryAddressText: formattedAddressText,
        deliveryPlaceName: placeNameText,
        deliveryFormattedAddress: formattedAddressText,
        deliveryLatitude: latitudeNum,
        deliveryLongitude: longitudeNum,
        distanceKm: quote.distanceKm,
        locationSource: locationSourceText,
        paymentMethod: dto.paymentMethod,
        paymentVerified: true,
      });
    }

    const sanitizedOrder: any = serializePrisma(order);
    delete sanitizedOrder.pricingSnapshot;
    delete sanitizedOrder.taxSnapshot;
    delete sanitizedOrder.restaurantSnapshot;
    delete sanitizedOrder.customerSnapshot;

    return sanitizedOrder;
  }

  async updateStatus(
    orderId: string,
    dto: UpdateOrderStatusDto,
    changedBy?: string,
    userRole?: string,
  ) {
    const order = await this.repo.findById(orderId);

    if (
      userRole === 'RESTAURANT_OWNER' ||
      userRole === 'RESTAURANT_MANAGER' ||
      userRole === 'RESTAURANT_STAFF'
    ) {
      const allowed: OrderStatus[] = [OrderStatus.PREPARING, OrderStatus.CANCELLED];

      if (!allowed.includes(dto.status as OrderStatus)) {
        throw new ForbiddenException('Restaurant cannot change order to this status');
      }
    }

    // Driver permissions
    if (userRole === 'DRIVER') {
      const allowed: OrderStatus[] = [OrderStatus.OUT_FOR_DELIVERY, OrderStatus.DELIVERED];

      if (!allowed.includes(dto.status as OrderStatus)) {
        throw new ForbiddenException('Driver cannot change order to this status');
      }
    }

    return this.lifecycle.updateOrderStatus(orderId, dto.status as OrderStatus, changedBy);
  }

  async cancelOrder(orderId: string, dto: CancelOrderDto, cancelledByUserId: string) {
    const order = await this.repo.findById(orderId);

    // ── 1. OWNERSHIP CHECK ────────────────────────────────────────────────────
    // Resolve the authenticated userId to a Customer record and verify ownership.
    const customer = await this.prisma.customer.findFirst({
      where: { OR: [{ userId: cancelledByUserId }, { id: cancelledByUserId }] },
    });
    const customerId = customer?.id;
    if (!customerId || order.customerId !== customerId) {
      throw new ForbiddenException('You are not authorised to cancel this order.');
    }

    // ── 2. IDEMPOTENCY ────────────────────────────────────────────────────────
    // If already cancelled just return success (handles double-click / retry).
    if (order.status === OrderStatus.CANCELLED) {
      return { message: 'Order is already cancelled.' };
    }

    // ── 3. CANCELLATION POLICY (existing rules) ───────────────────────────────
    // Customers may cancel only while the order is PENDING or ACCEPTED.
    // Once the restaurant starts PREPARING, cancellation is no longer allowed.
    const cancellableStatuses: OrderStatus[] = [OrderStatus.PENDING, OrderStatus.ACCEPTED];
    if (!cancellableStatuses.includes(order.status)) {
      const friendlyStatus: Record<string, string> = {
        PREPARING: 'the restaurant has already started preparing your order',
        DRIVER_ASSIGNED: 'a rider has already been assigned',
        ARRIVED_AT_RESTAURANT: 'the rider has arrived at the restaurant',
        PICKED_UP: 'the rider has already picked up your order',
        OUT_FOR_DELIVERY: 'your order is already out for delivery',
        DELIVERED: 'your order has already been delivered',
        REJECTED: 'this order was rejected by the restaurant',
      };
      const reason = friendlyStatus[order.status] ?? `the order is in ${order.status} state`;
      throw new ForbiddenException(
        `This order can no longer be cancelled because ${reason}.`,
      );
    }

    // ── 4. ATOMIC TRANSACTION ─────────────────────────────────────────────────
    await this.prisma.$transaction([
      this.prisma.order.update({
        where: { id: orderId },
        data: { status: OrderStatus.CANCELLED },
      }),
      this.prisma.orderCancellation.create({
        data: { orderId, reason: dto.reason, cancelledBy: cancelledByUserId },
      }),
      this.prisma.orderTimeline.create({
        data: { orderId, status: OrderStatus.CANCELLED, message: `Cancelled by customer: ${dto.reason}` },
      }),
    ]);

    // ── 5. REAL-TIME NOTIFICATIONS (after commit) ─────────────────────────────
    // Notify all parties watching this order (customer tracking page)
    this.gateway.emitToOrder(orderId, ORDER_EVENTS.ORDER_CANCELLED, {
      orderId,
      reason: dto.reason,
    });

    // Notify restaurant dashboard via socket
    this.gateway.emitToRestaurant(order.restaurantId, ORDER_EVENTS.ORDER_CANCELLED, {
      orderId,
      orderNumber: order.orderNumber,
      reason: dto.reason,
    });

    // Notify restaurant via Web Push so they see it even if the tab is closed
    this.webPushService.sendPushNotification(order.restaurantId, {
      title: `Order #${order.orderNumber} Cancelled`,
      body: `Customer cancelled the order. Reason: ${dto.reason}`,
      url: '/orders',
    });

    return { message: 'Order cancelled successfully.' };
  }

  async getOrderWithTimeline(orderId: string) {
    const res: any = await this.repo.findById(orderId);
    delete res.pricingSnapshot;
    delete res.taxSnapshot;
    delete res.restaurantSnapshot;
    delete res.customerSnapshot;
    delete res.restaurantSettlement;
    delete res.riderSettlement;
    return serializePrisma(res);
  }

  async getCustomerOrders(customerId: string, page: number, limit: number) {
    const res = await this.repo.findByCustomer(customerId, page, limit);
    const sanitized = res.map((order: any) => {
      delete order.pricingSnapshot;
      delete order.taxSnapshot;
      delete order.restaurantSnapshot;
      delete order.customerSnapshot;
      delete order.restaurantSettlement;
      delete order.riderSettlement;
      return order;
    });
    return serializePrisma(sanitized);
  }

  async getRestaurantOrders(
    restaurantId: string,
    status?: OrderStatus,
    page?: number,
    limit?: number,
  ) {
    const res = await this.repo.findByRestaurant(restaurantId, status, page, limit);
    return serializePrisma(res);
  }

  async getAllOrders(status?: any, page = 1, limit = 20) {
    const res = await this.repo.findAll(status, page, limit);
    return serializePrisma(res);
  }

  async getDriverOrders(driverId: string, page: number, limit: number) {
    const res = await this.repo.findByDriver(driverId, page, limit);
    return serializePrisma(res);
  }

  async generateInvoice(orderId: string) {
    const order = await this.repo.findById(orderId);

    return {
      invoiceNumber: `INV-${order.orderNumber}`,
      orderId: order.id,
      orderNumber: order.orderNumber,
      placedAt: order.createdAt,
      items: order.orderItems.map((i) => ({
        name: (i as any).foodItem?.name ?? 'Item',
        quantity: i.quantity,
        unitPrice: Number(i.unitPrice),
        totalPrice: Number(i.totalPrice),
      })),
      subtotal: Number(order.subtotal),
      discountAmount: Number(order.discountAmount),
      packagingFee: Number(order.packagingFee),
      deliveryFee: Number(order.deliveryFee),
      taxAmount: Number(order.taxAmount),
      grandTotal: Number(order.totalAmount),
      paymentStatus: order.paymentStatus,
      paymentMethod: order.paymentMethod,
      deliveryAddress: order.deliveryAddress,
    };
  }

  async repeatOrder(orderId: string, userId?: string) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: {
        orderItems: { include: { foodItem: true } },
        restaurant: true,
      },
    });
    if (!order) throw new NotFoundException(`Order ${orderId} not found`);

    return serializePrisma({
      orderId: order.id,
      restaurantId: order.restaurantId,
      restaurantName: order.restaurant?.name || 'Restaurant',
      items: order.orderItems.map((item) => ({
        foodItemId: item.foodItemId,
        name: item.foodItem?.name || 'Food Item',
        price: Number(item.unitPrice),
        quantity: item.quantity,
        addonsJson: item.addonsJson ?? undefined,
      })),
      totalAmount: Number(order.totalAmount),
    });
  }

  async assignSelfDeliveryRider(orderId: string, riderId: string) {
    const order = await this.prisma.order.findUniqueOrThrow({
      where: { id: orderId },
      include: { restaurant: true },
    });

    const rider = await this.prisma.restaurantDeliveryStaff.findUniqueOrThrow({
      where: { id: riderId },
    });

    await this.prisma.$transaction([
      this.prisma.order.update({
        where: { id: orderId },
        data: {
          assignedRestaurantDriverId: riderId,
          status: OrderStatus.DRIVER_ASSIGNED,
        },
      }),
      this.prisma.restaurantDeliveryStaff.update({
        where: { id: riderId },
        data: { status: 'BUSY' },
      }),
      this.prisma.orderTimeline.create({
        data: {
          orderId,
          status: OrderStatus.DRIVER_ASSIGNED,
          message: `Assigned self delivery rider ${rider.firstName} ${rider.lastName || ''}`.trim(),
        },
      }),
    ]);

    this.gateway.emitToOrder(orderId, ORDER_EVENTS.DRIVER_ASSIGNED, {
      orderId,
      riderName: `${rider.firstName} ${rider.lastName || ''}`.trim(),
      phone: rider.phone,
      vehicle: rider.vehicleNumber,
    });

    return { message: 'Self delivery rider assigned successfully', rider };
  }

  async getSelfRiderOrders(riderId: string, page: number = 1, limit: number = 20) {
    const skip = (page - 1) * limit;
    return this.prisma.order.findMany({
      where: { assignedRestaurantDriverId: riderId },
      include: {
        customer: { include: { user: { include: { profile: true } } } },
        restaurant: true,
        orderItems: { include: { foodItem: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    });
  }

  async updateSelfDeliveryStatus(orderId: string, status: string, otp?: string) {
    const order = await this.prisma.order.findUniqueOrThrow({ where: { id: orderId } });

    // OTP requirement removed from delivery completion

    const nextStatus = status as OrderStatus;

    await this.prisma.$transaction([
      this.prisma.order.update({
        where: { id: orderId },
        data: { status: nextStatus },
      }),
      this.prisma.orderTimeline.create({
        data: {
          orderId,
          status: nextStatus,
          message: `Self delivery status updated to ${nextStatus}`,
        },
      }),
      ...(status === 'DELIVERED' && order.assignedRestaurantDriverId
        ? [
            this.prisma.restaurantDeliveryStaff.update({
              where: { id: order.assignedRestaurantDriverId },
              data: { status: 'AVAILABLE' },
            }),
          ]
        : []),
    ]);

    this.gateway.emitToOrder(orderId, ORDER_EVENTS.STATUS_UPDATED, {
      orderId,
      status: nextStatus,
    });

    return { message: `Order status updated to ${nextStatus}` };
  }

  // --- CUSTOMER ORDER TRACKING & HISTORY METHODS ---

  // --- CUSTOMER ORDER TRACKING & HISTORY METHODS ---

  async getActiveCustomerOrder(userId: string) {
    try {
      const activeOrder = await this.prisma.order.findFirst({
        where: {
          customer: { userId },
          status: {
            in: [
              OrderStatus.PENDING,
              OrderStatus.ACCEPTED,
              OrderStatus.PREPARING,
              OrderStatus.DRIVER_ASSIGNED,
              OrderStatus.ARRIVED_AT_RESTAURANT,
              OrderStatus.PICKED_UP,
              OrderStatus.OUT_FOR_DELIVERY,
            ],
          },
          deletedAt: null,
        },
        include: {
          restaurant: true,
          orderItems: { include: { foodItem: true } },
          orderTimelines: { orderBy: { createdAt: 'asc' } },
          tracking: true,
          assignedRestaurantDriver: true,
          deliveryJob: {
            include: {
              driver: {
                include: {
                  user: { include: { profile: true } },
                  vehicles: true,
                },
              },
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      });

      if (!activeOrder) return null;

      const deliveryAddress: any = activeOrder.deliveryAddress || {};
      const restaurantLat = activeOrder.restaurant
        ? Number(activeOrder.restaurant.latitude || 0)
        : 0;
      const restaurantLng = activeOrder.restaurant
        ? Number(activeOrder.restaurant.longitude || 74.5221)
        : 74.5221;
      const customerLat =
        typeof deliveryAddress?.latitude === 'number' ? deliveryAddress.latitude : restaurantLat;
      const customerLng =
        typeof deliveryAddress?.longitude === 'number' ? deliveryAddress.longitude : restaurantLng;
      const driverLat = activeOrder.tracking?.currentLat || restaurantLat + 0.003;
      const driverLng = activeOrder.tracking?.currentLng || restaurantLng + 0.003;

      const distKm = Math.sqrt(
        Math.pow((customerLat - driverLat) * 111, 2) + Math.pow((customerLng - driverLng) * 111, 2),
      );
      const etaMins = isNaN(distKm) ? 15 : Math.max(10, Math.ceil((distKm / 25) * 60) + 10);

      const customerAddressText =
        typeof deliveryAddress === 'string'
          ? deliveryAddress
          : deliveryAddress.formattedAddress ||
            [deliveryAddress.addressLine1, deliveryAddress.city].filter(Boolean).join(', ') ||
            'Delivery Address';

      const foodHubDriver = activeOrder.deliveryJob?.driver;
      const driverProfile = foodHubDriver?.user?.profile;
      const driverName = driverProfile
        ? `${driverProfile.firstName} ${driverProfile.lastName || ''}`.trim()
        : activeOrder.assignedRestaurantDriver
          ? `${activeOrder.assignedRestaurantDriver.firstName} ${activeOrder.assignedRestaurantDriver.lastName || ''}`.trim()
          : 'Assigned Partner';

      const driverPhone =
        foodHubDriver?.user?.phone ||
        activeOrder.assignedRestaurantDriver?.phone ||
        '+919876543210';
      const vehicleNumber =
        foodHubDriver?.vehicles?.[0]?.vehicleNumber ||
        activeOrder.assignedRestaurantDriver?.vehicleNumber ||
        'JK-15-A-1001';

      return serializePrisma({
        orderId: activeOrder.id,
        orderNumber: activeOrder.orderNumber,
        restaurantName: activeOrder.restaurant?.name || 'FoodHub Restaurant',
        restaurantAddress: activeOrder.restaurant?.addressLine || '',
        restaurantLat,
        restaurantLng,
        customerAddress: customerAddressText,
        customerLat,
        customerLng,
        driverLat,
        driverLng,
        driverName,
        driverPhone,
        vehicleNumber,

        etaMins,
        status: activeOrder.status,
        placedAt: activeOrder.createdAt,
        items: (activeOrder.orderItems || []).map((i) => ({
          name: i.foodItem?.name || 'Item',
          quantity: i.quantity,
          price: Number(i.unitPrice),
        })),
        totalAmount: Number(activeOrder.totalAmount),
      });
    } catch (err) {
      this.logger.error('Error in getActiveCustomerOrder', err);
      return null;
    }
  }

  async getCustomerOrderHistory(userId: string, statusFilter?: string, page: number = 1, limit: number = 20) {
    const skip = (page - 1) * limit;
    let whereClause: any = {
      customer: { userId },
      deletedAt: null,
    };

    if (statusFilter && statusFilter !== 'ALL') {
      if (statusFilter === 'ACTIVE') {
        whereClause.status = {
          in: [
            OrderStatus.PENDING,
            OrderStatus.ACCEPTED,
            OrderStatus.PREPARING,
            OrderStatus.DRIVER_ASSIGNED,
            OrderStatus.ARRIVED_AT_RESTAURANT,
            OrderStatus.PICKED_UP,
            OrderStatus.OUT_FOR_DELIVERY,
          ],
        };
      } else if (statusFilter === 'DELIVERED') {
        whereClause.status = OrderStatus.DELIVERED;
      } else if (statusFilter === 'CANCELLED') {
        whereClause.status = {
          in: [OrderStatus.CANCELLED, OrderStatus.REJECTED, OrderStatus.FAILED],
        };
      } else {
        whereClause.status = statusFilter as any;
      }
    }

    const orders = await this.prisma.order.findMany({
      where: whereClause,
      include: {
        restaurant: true,
        orderItems: { include: { foodItem: true } },
        orderTimelines: { orderBy: { createdAt: 'asc' } },
        tracking: true,
        cancellation: true,
        refund: true,
        deliveryJob: {
          include: {
            driver: {
              include: {
                user: { include: { profile: true } },
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    });

    return serializePrisma(
      orders.map((ord) => ({
        id: ord.id,
        orderNumber: ord.orderNumber,
        restaurantName: ord.restaurant?.name || 'Restaurant',
        restaurantBanner: ord.restaurant?.bannerUrl,
        date:
          ord.createdAt.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }) +
          ' ' +
          ord.createdAt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Kolkata' }),
        createdAt: ord.createdAt,
        deliveredAt: ord.deliveryJob?.deliveredAt || ord.updatedAt,
        totalAmount: Number(ord.totalAmount),
        itemCount: ord.orderItems.reduce((acc, i) => acc + i.quantity, 0),
        itemsSummary: ord.orderItems
          .map((i) => `${i.quantity}x ${i.foodItem?.name || 'Item'}`)
          .join(', '),
        items: ord.orderItems.map((i) => ({
          id: i.id,
          name: i.foodItem?.name || 'Item',
          quantity: i.quantity,
          unitPrice: Number(i.unitPrice),
          totalPrice: Number(i.totalPrice),
        })),
        status: ord.status,
        paymentStatus: ord.paymentStatus,
        paymentMethod: ord.paymentMethod,
        cancellationReason: ord.cancellation?.reason,
        isRefunded: !!ord.refund,
      })),
    );
  }

  async getOrderWithTimelineSecured(orderId: string, userId: string, role?: string) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: {
        restaurant: true,
        customer: { include: { user: { include: { profile: true } } } },
        orderItems: { include: { foodItem: true } },
        orderTimelines: { orderBy: { createdAt: 'asc' } },
        statusHistories: { orderBy: { createdAt: 'asc' } },
        tracking: true,
        cancellation: true,
        refund: true,
        assignedRestaurantDriver: true,
        payments: true,
        restaurantReviews: true,
      },
    });

    if (!order) {
      throw new BadRequestException(`Order ${orderId} not found`);
    }

    // STRICT CUSTOMER, RESTAURANT & DRIVER AUTHORIZATION CHECK
    const isCustomerOwner =
      order.customer.userId === userId ||
      order.customerId === userId ||
      order.customer.id === userId;
    const isAdmin = role === 'SUPER_ADMIN' || role === 'ADMIN';

    let isAuthorized = isCustomerOwner || isAdmin;

    if (
      !isAuthorized &&
      (role === 'RESTAURANT_OWNER' || role === 'RESTAURANT_MANAGER' || role === 'RESTAURANT_STAFF')
    ) {
      const isOwner = order.restaurant.ownerId === userId;
      const isStaff = await this.prisma.restaurantStaff.findFirst({
        where: { restaurantId: order.restaurantId, userId },
        select: { id: true },
      });
      if (isOwner || isStaff) {
        isAuthorized = true;
      }
    }

    if (!isAuthorized && (role === 'DRIVER' || role === 'DELIVERY_PARTNER')) {
      const driver = await this.prisma.driver.findFirst({
        where: { userId },
        select: { id: true },
      });
      if (driver) {
        const isAssigned = order.assignedRestaurantDriverId === driver.id;
        const job = await this.prisma.deliveryJob.findFirst({
          where: { orderId: order.id, driverId: driver.id },
          select: { id: true },
        });
        if (isAssigned || job) {
          isAuthorized = true;
        }
      }
    }

    if (!isAuthorized) {
      throw new ForbiddenException('You do not have permission to view this order.');
    }

    const serialized: any = serializePrisma(order);
    
    // CUSTOMER & DRIVER MUST NEVER SEE FINANCIAL SNAPSHOTS OR SETTLEMENTS
    const isRestaurantRole = role === 'RESTAURANT_OWNER' || role === 'RESTAURANT_MANAGER' || role === 'RESTAURANT_STAFF';
    
    if (!isAdmin && !isRestaurantRole) {
      delete serialized.pricingSnapshot;
      delete serialized.taxSnapshot;
      delete serialized.restaurantSnapshot;
      delete serialized.customerSnapshot;
      delete serialized.restaurantSettlement;
      delete serialized.riderSettlement;
    }

    // Always redact OTP fields from all responses
    delete serialized.deliveryOtp;
    delete serialized.deliveryOtpHash;
    delete serialized.deliveryOtpExpiresAt;
    delete serialized.deliveryOtpAttempts;

    return serialized;
  }

  async getOrderTrackingSecured(orderId: string, userId: string, role?: string) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      select: {
        id: true,
        orderNumber: true,
        status: true,
        customerId: true,
        restaurantId: true,
        assignedRestaurantDriverId: true,
        deliveryAddress: true,
        restaurant: {
          select: {
            name: true,
            latitude: true,
            longitude: true,
            ownerId: true,
          }
        },
        assignedRestaurantDriver: {
          select: {
            firstName: true,
            lastName: true,
            phone: true,
            vehicleNumber: true,
          }
        }
      }
    });

    if (!order) throw new BadRequestException(`Order ${orderId} not found`);

    const isAdmin = role === 'SUPER_ADMIN' || role === 'ADMIN';
    let isAuthorized = isAdmin || order.customerId === userId;

    if (!isAuthorized && (role === 'RESTAURANT_OWNER' || role === 'RESTAURANT_MANAGER' || role === 'RESTAURANT_STAFF')) {
      const isOwner = order.restaurant.ownerId === userId;
      if (isOwner) {
        isAuthorized = true;
      } else {
        const isStaff = await this.prisma.restaurantStaff.findFirst({
          where: { restaurantId: order.restaurantId, userId },
          select: { id: true },
        });
        if (isStaff) isAuthorized = true;
      }
    }

    if (!isAuthorized && (role === 'DRIVER' || role === 'DELIVERY_PARTNER')) {
      const driver = await this.prisma.driver.findFirst({
        where: { userId },
        select: { id: true },
      });
      if (driver) {
        if (order.assignedRestaurantDriverId === driver.id) {
          isAuthorized = true;
        } else {
          const job = await this.prisma.deliveryJob.findFirst({
            where: { orderId: order.id, driverId: driver.id },
            select: { id: true },
          });
          if (job) isAuthorized = true;
        }
      }
    }

    if (!isAuthorized) {
      throw new ForbiddenException('You do not have permission to view delivery tracking for this order.');
    }

    const deliveryAddress: any = order.deliveryAddress || {};
    const restaurantLat = Number(order.restaurant.latitude) || 0;
    const restaurantLng = Number(order.restaurant.longitude) || 0;
    const customerLat = Number(deliveryAddress?.latitude) || 0;
    const customerLng = Number(deliveryAddress?.longitude) || 0;

    let driverLat = null;
    let driverLng = null;

    if (order.status !== 'DELIVERED') {
      try {
        const liveLoc = await this.redisService.getClient().get(`driver_loc_${orderId}`);
        if (liveLoc) {
          const parsed = JSON.parse(liveLoc);
          driverLat = parsed.lat;
          driverLng = parsed.lng;
        } else {
          // Fallback to DB if Redis has no data
          const tracking = await this.prisma.orderTracking.findUnique({
            where: { orderId },
            select: { currentLat: true, currentLng: true }
          });
          if (tracking) {
            driverLat = Number(tracking.currentLat);
            driverLng = Number(tracking.currentLng);
          }
        }
      } catch (e) {
        this.logger.warn(`Redis fetch failed for driver location: ${e.message}`);
      }
    }

    let routeCoordinates: [number, number][] = [];
    let roadDistanceKm: number | null = null;
    let etaMins = 15;

    let routeStartLat = restaurantLat;
    let routeStartLng = restaurantLng;
    let routeEndLat = customerLat;
    let routeEndLng = customerLng;

    const hasDriverLoc = driverLat && driverLng;
    const isPickedUp = order.status === 'PICKED_UP' || order.status === 'OUT_FOR_DELIVERY' || order.status === 'DELIVERED';

    if (hasDriverLoc) {
      if (isPickedUp) {
        routeStartLat = driverLat;
        routeStartLng = driverLng;
      } else {
        routeStartLat = driverLat;
        routeStartLng = driverLng;
        routeEndLat = restaurantLat;
        routeEndLng = restaurantLng;
      }
    }

    if (routeStartLat && routeStartLng && routeEndLat && routeEndLng) {
      const cacheKey = `route_geom_${orderId}_${routeStartLat.toFixed(3)}_${routeStartLng.toFixed(3)}`;
      let cachedRoute = null;
      try {
        const val = await this.redisService.getClient().get(cacheKey);
        if (val) cachedRoute = JSON.parse(val);
      } catch (e) {}

      if (cachedRoute) {
        routeCoordinates = cachedRoute.coordinates;
        roadDistanceKm = cachedRoute.distanceKm;
        etaMins = cachedRoute.etaMinutes;
      } else {
        try {
          const routeData = await this.geolocationService.getRouteGeometry(routeStartLat, routeStartLng, routeEndLat, routeEndLng);
          routeCoordinates = routeData.coordinates;
          roadDistanceKm = routeData.distanceKm;
          etaMins = routeData.etaMinutes;
          
          this.redisService.getClient().setex(cacheKey, 60, JSON.stringify(routeData)).catch(() => {});
        } catch (err: any) {
          this.logger.warn(`[Order Tracking] Could not fetch Mappls road route geometry for order ${orderId}: ${err?.message || err}`);
        }
      }
    }

    return serializePrisma({
      orderId: order.id,
      orderNumber: order.orderNumber,
      status: order.status,
      restaurantName: order.restaurant.name,
      restaurantLat,
      restaurantLng,
      customerLat,
      customerLng,
      driverLat,
      driverLng,
      driverName: order.assignedRestaurantDriver
        ? `${order.assignedRestaurantDriver.firstName} ${order.assignedRestaurantDriver.lastName || ''}`.trim()
        : 'Delivery Partner',
      driverPhone: order.assignedRestaurantDriver?.phone || '+919876543210',
      vehicleNumber: order.assignedRestaurantDriver?.vehicleNumber || 'KA-01-EE-9482',
      etaMins,
      distanceKm: roadDistanceKm,
      routeCoordinates,
      updatedAt: new Date(),
    });
  }

  async updateDriverLocation(orderId: string, lat: number, lng: number, userId: string) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
    });
    if (!order) throw new BadRequestException(`Order ${orderId} not found`);

    const tracking = await this.prisma.orderTracking.upsert({
      where: { orderId },
      update: { currentLat: lat, currentLng: lng },
      create: { orderId, currentLat: lat, currentLng: lng },
    });

    this.gateway.emitToOrder(orderId, ORDER_EVENTS.DRIVER_LOCATION, {
      orderId,
      lat,
      lng,
      updatedAt: tracking.updatedAt,
    });

    return serializePrisma(tracking);
  }

  async submitOrderReview(orderId: string, rating: number, userId: string) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: { customer: true },
    });
    if (!order) throw new NotFoundException('Order not found');
    if (order.status !== 'DELIVERED') throw new ForbiddenException('Order not delivered yet');

    const review = await this.prisma.restaurantReview.create({
      data: {
        orderId: order.id,
        restaurantId: order.restaurantId,
        customerId: order.customerId,
        rating: Math.min(5, Math.max(1, rating)),
      },
    });

    // Recalculate and update restaurant's aggregate avgRating in database
    const ratingStats = await this.prisma.restaurantReview.aggregate({
      where: { restaurantId: order.restaurantId },
      _avg: { rating: true },
    });

    if (ratingStats._avg.rating !== null && ratingStats._avg.rating !== undefined) {
      await this.prisma.restaurant.update({
        where: { id: order.restaurantId },
        data: { avgRating: Math.round(ratingStats._avg.rating * 10) / 10 },
      });
    }

    return serializePrisma(review);
  }

  async getOrderInvoice(orderId: string, userId: string, role?: string) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: {
        restaurant: true,
        customer: { include: { user: { include: { profile: true } } } },
        orderItems: true,
      },
    });

    if (!order) {
      throw new BadRequestException(`Order ${orderId} not found`);
    }

    const isCustomer = order.customer?.userId === userId;
    const isRestaurantOwner = order.restaurant?.ownerId === userId;
    const isAdmin = role === 'ADMIN' || role === 'SUPER_ADMIN';

    if (!isCustomer && !isRestaurantOwner && !isAdmin) {
      throw new BadRequestException(
        'Access denied. You do not have permission to view this invoice.',
      );
    }

    let invoice = await this.prisma.invoice.findUnique({
      where: { orderId: order.id },
    });

    if (!invoice) {
      const invoiceNumber = `INV-${order.orderNumber}`;
      invoice = await this.prisma.invoice.create({
        data: {
          invoiceNumber,
          orderId: order.id,
          pdfUrl: `/api/orders/${order.id}/invoice/pdf`,
        },
      });
    }

    const snap: any = order.pricingSnapshot || {};

    const foodSubtotal =
      snap.restaurantGross !== undefined
        ? Number(snap.restaurantGross)
        : Number(order.subtotal || 0);
    const platformFee = snap.platformFee !== undefined ? Number(snap.platformFee) : 3.0;
    const totalCustomerTaxes =
      snap.totalCustomerTaxes !== undefined ? Number(snap.totalCustomerTaxes) : 0;
    const discountAmount = snap.discountAmount !== undefined ? Number(snap.discountAmount) : 0;
    const customerTotal = Number(order.totalAmount);

    const commissionRate = snap.commissionRate !== undefined ? Number(snap.commissionRate) : 13.0;
    const commissionAmount =
      snap.commissionAmount !== undefined
        ? Number(snap.commissionAmount)
        : Math.round(((foodSubtotal * commissionRate) / 100) * 100) / 100;

    const commissionGstAmount =
      snap.commissionGstAmount !== undefined
        ? Number(snap.commissionGstAmount)
        : snap.restaurantCommissionGst !== undefined
          ? Number(snap.restaurantCommissionGst)
          : Math.round(commissionAmount * 0.18 * 100) / 100;

    const restaurantNet =
      snap.restaurantNet !== undefined
        ? Number(snap.restaurantNet)
        : Math.round((foodSubtotal - commissionAmount - commissionGstAmount) * 100) / 100;
    const deliveryFee =
      snap.customerDeliveryFee !== undefined ? Number(snap.customerDeliveryFee) : 0;
    const packagingFee = snap.packagingFee !== undefined ? Number(snap.packagingFee) : 0;

    const response: any = {
      invoiceDetails: {
        invoiceId: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
        createdAt: invoice.createdAt,
        orderId: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
        paymentStatus: order.paymentStatus,
        pdfUrl: invoice.pdfUrl,
      },
      customerInvoice: {
        title: 'Customer Invoice / Receipt',
        foodSubtotal,
        packagingFee,
        deliveryFee,
        taxes: totalCustomerTaxes,
        platformFee,
        discounts: discountAmount,
        totalPaid: customerTotal,
        note: 'Platform Fee is a customer-side charge.',
      },
      items: order.orderItems.map((item: any) => ({
        name: (item.itemSnapshot as any)?.foodName || 'Item',
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        totalPrice: item.totalPrice,
      })),
      parties: {
        restaurant: {
          name: order.restaurant.name,
          address: (order.restaurant as any).addressLine || 'Registered Address',
        },
        customer: {
          name: order.customer?.user?.profile
            ? `${order.customer.user.profile.firstName} ${order.customer.user.profile.lastName || ''}`.trim()
            : 'Customer',
        },
      },
    };

    if (isAdmin || isRestaurantOwner) {
      response.restaurantStatement = {
        title: 'Restaurant Settlement Statement',
        grossSales: foodSubtotal,
        commissionRate,
        commissionDeduction: commissionAmount,
        commissionGstDeduction: commissionGstAmount,
        platformFeeDeduction: 0,
        netPayable: restaurantNet,
        note: 'Customer platform fee is excluded from restaurant deductions.',
      };
    }

    return serializePrisma(response);
  }
}
